sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("QuickStartApplication.controller.App", {
		//when user clicks on any item we would send the selected item index to the second pafe 

	});

});