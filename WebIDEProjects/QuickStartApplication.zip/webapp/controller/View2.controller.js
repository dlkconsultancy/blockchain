sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("QuickStartApplication.controller.View2", {

		onInit: function() {

			//get the router details passed from first Page to Detail page when table item onPress event is triggered 
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("View2").attachPatternMatched(this._onDetailMatched, this);
		},
		_onDetailMatched: function(oEvent) {

			var sObjectPath = "/zcustomeronsecondpageSet('" + oEvent.getParameter("arguments").id + "')";
			//					var oView = this.getView();
			//			oView.bindElement(sObjectPath);
			var oModel = this.getView().getModel();
			var oView = this.getView();
			oModel.read(sObjectPath, {
				success: function(oRetrievedResult) {
					oView.byId("custNoId").setText(oRetrievedResult.Customerno);
					oView.byId("custIdName").setText(oRetrievedResult.Customername1);
					oView.byId("custIdMail").setText(oRetrievedResult.Customermail);
					oView.byId("custIdTele").setText(oRetrievedResult.Customertel);
					oView.byId("custStatus").setText(oRetrievedResult.Status);
				},
				error: function() {
				sap.m.MessageToast.show("Error Loading service. Please contact administrator ");
				}
			});
		
		}
	});

});