sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("QuickStartApplication.controller.View1", {
		//when user clicks on any item we would send the selected item index to the second page 
		onSelectionChange: function(oEvent) {
				//get the selected index
			var oSelectedIndex  = oEvent.getSource().getSelectedContextPaths();
			var path= oEvent.getParameter('listItem').getBindingContext().getPath();
			var selectedRow= this.byId('Table_ID').getModel().getProperty(path);
			var oRouter = sap.ui.core.UIComponent
				.getRouterFor(this);
			oRouter.navTo("View2", {
				id: selectedRow.Customerno
			});
		}
	});

});